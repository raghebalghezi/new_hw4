from flask import Flask, render_template, request, redirect, send_from_directory
import speech_recognition as sr
from  fluency import speech_rate
from models import get_accuracy, get_range, get_fluency, get_pron
from werkzeug.utils import secure_filename
import glob, os
import random
import pandas as pd


for f in glob.glob("upload/*"):
    os.remove(f)

ALLOWED_EXTENSIONS = {'wav'}

app = Flask(__name__)

@app.route('/upload/<path:filename>')
def download_file(filename):
    return send_from_directory('upload/', filename)

@app.route("/", methods=["GET", "POST"])
def index():

    audio = ""
    transcript = ""
    fluency_info = ""
    task_achievement = ""
    pronunciation = ''
    range = ""
    accuracy = ""
    if request.method == "POST":
        print("FORM DATA RECEIVED")

        if "file" not in request.files:
            return redirect(request.url)

        file = request.files["file"]
        filename = secure_filename(file.filename)
        file_loc  = f'upload/{filename}'
        file.save(file_loc)

        if file.filename == "":
            return redirect(request.url)
        
        r = sr.Recognizer()
        with sr.AudioFile(file_loc) as source:
            audio = r.record(source)  # read the entire audio file

        transcript = r.recognize_google(audio, show_all=False, language="sv")

        # fluency_info = get_fluency(list(speech_rate(f'upload/{filename}').values)[1:])
        info = pd.DataFrame(speech_rate(file_loc), index=[0]).drop('soundname', axis=1)
        fluency_info =  get_fluency(info)

        task_achievement = f" {random.choice([1,2,3])} out of 3 (unreal score)"
        range = get_range(transcript) 
        accuracy = get_accuracy(transcript) 
        pronunciation = get_pron(info)
        audio = f"""<audio controls><source src="{file_loc}" type="audio/wav"></audio>"""
        

    return render_template('index.html', transcript=transcript, \
        fluency=fluency_info, taskAchievement=task_achievement, range=range, \
            accuracy=accuracy, pronunciation=pronunciation, audiopath=audio)


if __name__ == "__main__":
    app.run(debug=True, threaded=True)