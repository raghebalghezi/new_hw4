import joblib
import eli5
from eli5.lime import TextExplainer

range_model = joblib.load('range_xgboost.mdl')
accuracy_model = joblib.load('accuracy_xgboost.mdl')
fluency_model = joblib.load('fluency_xgboost.mdl')
pronunciation_model = joblib.load('pronunciation_xgboost.mdl')
te = TextExplainer(random_state=42)

show_var  = ('targets',  'decision_tree')

def get_range(txt):
    te.fit(txt, range_model.predict_proba)
    pred = eli5.format_as_html(te.explain_prediction(target_names=['A (Beginner)',"B (Intermediate)","C (Advanced)"]), show=show_var, force_weights=False)
    return pred

def get_accuracy(txt):
    te.fit(txt, accuracy_model.predict_proba)
    pred = eli5.format_as_html(te.explain_prediction(target_names=['A (Beginner)',"B (Intermediate)","C (Advanced)"]), show=show_var, force_weights=False)
    return pred

def get_fluency(txt):
    pred = eli5.format_as_html(eli5.explain_prediction(fluency_model, txt.iloc[0]),  show_feature_values=True, show=show_var)
    return pred

def get_pron(txt):
    pred = eli5.format_as_html(eli5.explain_prediction(pronunciation_model, txt.iloc[0]), show_feature_values=True, show=show_var)
    return pred